/*
 *Yulok app
 *By Carlos Fernandez Jimenez
 *Define app constants
 */
 
(function() {
    'use strict';
    angular
        .module('yulok')
        .constant('API_URL', 'http://yulokcr.com/Servidor');

})();